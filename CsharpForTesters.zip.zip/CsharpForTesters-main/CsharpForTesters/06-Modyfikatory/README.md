﻿## Modyfikatory dostępu

#### Zadanie 1
W klasie `Modyfikatory.cs` utwórz zmienne klasowe jak poniżej (nie twórz tam funkcji main)
1. private String film
2. protected String rezyser
3. private String scenarzysta
4. public double budzet

i nadaj im dowolne prawidłowe wartości.


#### Zadanie 2
1. W klasie `TestyModyfikatorow.cs` utwórz obiekt Modyfikatory
2. Spróbuj ustawić dowolne pola


#### Zadanie x - gettery i settery
1. Utwórz klasę User z prywatnym polem `int age`;
2. Napisz do niego publiczną metodę (setter) ustawiającą wartość wieku, ale tylko jeżeli podany wiek zawiera się w przedziale <1, 150>
3. Napisz do niego publiczną metodę (getter) pobierającą wartość wieku z prywatnego pola

#### Zadanie x - właściwości (properties)
1. Zrefaktoryzuj kod i zamiast pól prywatnych oraz metod, utwórz Właściwość (Property)