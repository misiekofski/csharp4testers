﻿using System;
using System.Collections.Generic;
using System.Text;

namespace CsharpForTesters._04_Struktury_danych
{
    public class Slowniki
    {
        public static void Main(string[] args)
        {
        }
    }
}
