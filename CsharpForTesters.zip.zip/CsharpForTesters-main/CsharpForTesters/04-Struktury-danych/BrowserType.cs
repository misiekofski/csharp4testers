﻿using System;
using System.Collections.Generic;
using System.Text;

namespace CsharpForTesters._04_Struktury_danych
{

// tu utwórz Enum

    //public class DriverFactory
    //{
    //    string driver = null;

    //    public static void Main(string[] args)
    //    {

    //    }

    //    public static string GetDriver(BrowserType browserType)
    //    {
    //        switch (browserType)
    //        {
    //            case browserType.Chrome:
    //                return "Chrome";
    //                break;

    //            default:
    //                return "Błędna przeglądarka";
    //        }
    //    }
    //}
}