﻿using System;
using System.Collections.Generic;
using System.Text;

namespace CsharpForTesters._02_Debugowanie
{
    public class KlasaPomocnicza
    {
        public static void Niespodzianka()
        {
            Console.WriteLine("Niespodzianka!");
        }
    }
}
