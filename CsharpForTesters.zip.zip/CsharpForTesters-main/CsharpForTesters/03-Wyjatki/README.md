﻿## Wyjątki

#### Zadanie 1
1. Uruchom program w klasie `Wyjatki.cs`
2. Dlaczego napis `A to się powinno wydrukować niezależnie od wszystkiego` nie został wydrukowany?
3. Nie zmieniając wartości `b` ani obliczeń zmiennej `c` popraw program tak aby powyższy napis został wydrukowany.



#### Zadanie 2
1. Wejdź do klasy `RzucanieWyjatkow.cs` i zobacz kod aplikacji
2. Popraw metodę `GetMax()` tak aby *rzucała* wyjątek `ArgumentException` jeżeli długość tablicy przekazanej jako parametr wynosi 0 (tablica jest pusta)
3. Popraw kod metody `Main()` tak aby aplikacja się uruchomiła i wydrukowała informację o pustej tablicy przekazanej jako parametr.