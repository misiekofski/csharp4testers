﻿using System;
using System.Collections.Generic;
using System.Text;

namespace CsharpForTesters._01_Wstep
{
    public class Warunki
    {
        public static void Main(string[] args)
        {
        }
    }
}
