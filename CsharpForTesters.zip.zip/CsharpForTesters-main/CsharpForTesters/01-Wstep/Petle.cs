﻿using System;
using System.Collections.Generic;
using System.Text;

namespace CsharpForTesters._01_Wstep
{
    public class Petle
    {
        public static void Main(string[] args)
        {
        }
    }
}
