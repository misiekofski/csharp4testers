﻿using System;
using System.Collections.Generic;
using System.Text;

namespace CsharpForTesters._09_Linq
{
    public class Customer
    {
        public string Name { get; set; }
        public int OrdersQuantity { get; set; }
        public double TotalPurchasesAmount { get; set; }
        public string Bank { get; set; }
    }
}
