﻿using System;
using System.Collections.Generic;
using System.Text;

namespace CsharpForTesters._99_Inne
{
    public class TestujModyfikatory
    {
    }
}
